# rmq_custom_pack
### Custom package for more convenient use of RabbitMQ functions (producer and consumer).

## Command for installing
### - `pip install dist\rmq_custom_pack-0.0.1-py3-none-any.whl`
