import fake_classes_methods
import os
from typing import Any, Dict


#################################################### Test Methods ####################################################

fake_consumer_obj = fake_classes_methods.rpc_consumer.Consumer(host='test_host',
                                                        port=0,
                                                        user='test_user',
                                                        password='test_pass',
                                                        exchange='test_exchange',
                                                        exchange_type='test_exchange_type',
                                                        queue_request='test_queue_request',
                                                        queue_response='test_queue_response',
                                                        r_key_request='test_r_key_request',
                                                        r_key_response='test_r_key_response')
f = producer_handler_result = fake_consumer_obj.consumer_handler()

def test_consumer_handler():
    producer_handler_result = fake_consumer_obj.consumer_handler()

    assert producer_handler_result['basic_consume_res']['test_queue'] == 'test_queue_request'
    assert producer_handler_result['basic_consume_res']['test_auto_ack'] is False
    assert producer_handler_result['basic_consume_res']['test_exclusive'] is False
    assert producer_handler_result['basic_consume_res']['test_consumer_tag'] is None
    assert producer_handler_result['basic_consume_res']['test_arguments'] is None



